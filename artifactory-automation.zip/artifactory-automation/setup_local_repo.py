"""
Author: 		Peter Eames
Date: 		    May 2021
Decription: 	Setup local artifactory repo
Version:		3.0.0
Notes:          Script will run over a single instance and setup local repos
                Script requires the following inputs:
                    Admin USER ID
                    Admin USER Password
                    BU appreviation
                    Package Type
Changes:        3.0.0 - March 22 - Peter Eames
                    Updating to work with SAAS
"""

import getpass
import logging
import sys
import requests
import setup_virtual_repo
import utilities

# The different levels of logging, from highest urgency to lowest urgency, are:
# CRITICAL | ERROR | WARNING | INFO | DEBUG
logging.basicConfig(stream=sys.stderr, level=logging.DEBUG,
                    format='%(asctime)s - %(levelname)s - %(message)s')

try:
    USER = sys.argv[1]
except IndexError:
    USER = input('Username: ')
try:
    PWD = sys.argv[2]
except IndexError:
    PWD = getpass.getpass()
try:
    BU = sys.argv[3]
except IndexError:
    BU = input('BU: ')
try:
    PTYPE = sys.argv[4]
except IndexError:
    PTYPE = input('Package Type: ')
try:
    SD_USR = sys.argv[5]
except IndexError:
    SD_USR = input('AD Username: ')
try:
    SD_PWD = sys.argv[6]
except IndexError:
    SD_PWD = getpass.getpass()
try:
    SAILPOINTID = sys.argv[7]
except IndexError:
    SAILPOINTID = None
try:
    SAILPOINTPWD = sys.argv[8]
except IndexError:
    SAILPOINTPWD = None
try:
    SNOWUSER = sys.argv[9]
except IndexError:
    SNOWUSER = ''
try:
    SNOWPWD = sys.argv[10]
except IndexError:
    SNOWPWD = ''
try:
    REQUESTOR = sys.argv[11]
except IndexError:
    REQUESTOR = ''
try:
    POWNER = sys.argv[12]
except IndexError:
    POWNER = ''
try:
    SOWNER = sys.argv[13]
except IndexError:
    SOWNER = ''
try:
    OWN_MBR = sys.argv[14]
except IndexError:
    OWN_MBR = ''
try:
    PUB_MBR = sys.argv[15]
except IndexError:
    PUB_MBR = ''
try:
    DEV_MBR = sys.argv[16]
except IndexError:
    DEV_MBR = ''
try:
    ISSUE_KEY = sys.argv[17]
except IndexError:
    ISSUE_KEY = None
try:
    ENV = sys.argv[18]
except IndexError:
    ENV = ''

urlinstances = ['https://us-artifactory.prudential.com/artifactory']
HEADERS = {'content-type': 'application/json'}
PSETS = '["businessUnit","deploy"]'
JAVATYPES = ['maven', 'gradle', 'ivy']
status = []


def setname():
    """ This functions sets the name of the repo """
    if PTYPE.lower() in JAVATYPES:
        return BU.lower() + '-libs-release-local,' + BU.lower() + '-libs-snapshot-local,'\
               + BU.lower() + '-plugins-release-local,' + BU.lower()\
               + '-plugins-snapshot-local'
    return BU.lower() + '-' + PTYPE.lower() + '-local'


def setdata(name, layout):
    """ This function sets the data to be sent for the creation of a repo """
    return '{"key":"' + name + '","rclass":"local","packageType":\
        "' + PTYPE + '", "xrayIndex":true,"repoLayoutRef" :\
        "' + layout + '","propertySets": ' + PSETS + '}'


def main():
    """
    This is the main function that will create the local repo and
    call other functions to add repos to it
    """
    status = []
    name = setname()
    logging.debug(name)
    layout = utilities.setlayout(PTYPE)
    logging.debug(layout)
    name_list = name.split(",")
    utilities.add_sd_comment(SD_USR, SD_PWD, ISSUE_KEY, 'Automation Starting')
    for url in urlinstances:
        for repo in name_list:
            data = setdata(repo, layout)
            logging.debug(data)
            if "PASSD-" in ISSUE_KEY:
                utilities.add_sd_comment(SD_USR, SD_PWD, ISSUE_KEY,
                                         'Setting up ' + repo + ' in ' + url)
            try:
                response = requests.put(url + '/api/repositories/' + repo,
                                        auth=(USER, PWD), headers=HEADERS,
                                        data=data)
                response.raise_for_status()
            except requests.HTTPError:
                response = requests.post(url + '/api/repositories/' + repo,
                                         auth=(USER, PWD), headers=HEADERS,
                                         data=data)
            print_response(response)
        utilities.setpermissions(USER, PWD, BU, url, SD_USR, SD_PWD, ISSUE_KEY)
        utilities.setup_group_ad(BU, SD_USR, SD_PWD, REQUESTOR, POWNER, SOWNER,
                                 OWN_MBR, PUB_MBR, DEV_MBR, ISSUE_KEY,
                                 SAILPOINTID, SAILPOINTPWD)
        utilities.watch(url, USER, PWD, BU, SD_USR, SD_PWD, ISSUE_KEY)
    setup_virtual_repo.main(USER, PWD, PTYPE, urlinstances)
    if ISSUE_KEY is not None:
        if "failure" in status:
            if "PASSD-" in ISSUE_KEY:
                utilities.sd_transition(SD_USR, SD_PWD, ISSUE_KEY, 91)
            else:
                utilities.send_snow_failure_update(ENV, ISSUE_KEY, SNOWUSER, SNOWPWD)
        else:
            if "PASSD-" in ISSUE_KEY:
                utilities.sd_transition(SD_USR, SD_PWD, ISSUE_KEY, 21)
            else:
                utilities.send_snow_successs_update(ENV, ISSUE_KEY, SNOWUSER, SNOWPWD)


def print_response(response):
    """ function to print response details """
    if response.ok:
        logging.info(response.text)
        status.append('success')
    else:
        logging.error(response.reason)
        logging.error(response.text)
        status.append('failure')


if __name__ == "__main__":
    main()
