"""
Author: 		Peter Eames
Date: 		    May 2021
Decription: 	Setup remote artifactory repo
Version:		2.0.0
Notes:          Script will run over all Artifactory instances listed in the urlinstances list
                Script requires the following inputs:
                    Admin user ID
                    Admin user Password
                    Name of the repo to be setup (include -remote)
                    Type of repo - current suport Generic
                    URL of external repo
Changes:        2.0.0 - Nov 21 - Peter Eames
                    Changes to meet pylint standards,
                    removed common functions to utilities
                    call virtual repo is remote setup successful
"""

import getpass
import logging
import sys
import requests
import setup_virtual_repo
import utilities

# The different levels of logging, from highest urgency to lowest urgency, are:
# CRITICAL | ERROR | WARNING | INFO | DEBUG
logging.basicConfig(stream=sys.stderr, level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

try:
    user = sys.argv[1]
except IndexError:
    user = input('Username: ')
try:
    pwd = sys.argv[2]
except IndexError:
    pwd = getpass.getpass('API key: ')
try:
    ptype = sys.argv[3]
except IndexError:
    ptype = input('Package Type: ')

try:
    name = sys.argv[4]
except IndexError:
    name = input('Repo Name: ')

if '-remote' not in name:
    name = name + '-remote'

try:
    url = sys.argv[5]
except IndexError:
    url = input('URL: ')
try:
    rUser = sys.argv[6]
except IndexError:
    rUser = input('Remote URL User: ')
try:
    rPwd = sys.argv[7]
except IndexError:
    rPwd = input('Remote URL Password: ')
try:
    ISSUE_KEY = sys.argv[8]
except IndexError:
    ISSUE_KEY = input('Request ID: ')

urlinstances = ['https://us-artifactory.prudential.com/artifactory']
headers = {'content-type': 'application/json'}


def setdata(layout):
    """ This functions sets the data to be sent through for the creation of the remote repo """
    if ptype.lower() == "nuget":
        data = '{"key":"' + name + '","rclass":"remote","packageType":"' + ptype + '",\
"url":"' + url + '","username": "' + rUser + '","api key": "' + rPwd + '",\
"proxy":"Proxy","retrievalCachePeriodSecs": 43200,"missedRetrievalCachePeriodSecs": 7200,\
"unusedArtifactsCleanupPeriodHours": 4383,"assumedOfflinePeriodSecs":300,\
"fetchJarsEagerly":true,"fetchSourcesEagerly":true,"xrayIndex":true,\
"description":"Created for ' + ISSUE_KEY + '",\
"downloadContextPath": "api/v2/package",\
"repoLayoutRef" : "' + layout + '"}'
    else:
        data = '{"key":"' + name + '","rclass":"remote","packageType":"' + ptype + '",\
"url":"' + url + '","username": "' + rUser + '","api key": "' + rPwd + '",\
"proxy":"Proxy","retrievalCachePeriodSecs": 43200,"missedRetrievalCachePeriodSecs": 7200,\
"unusedArtifactsCleanupPeriodHours": 4383,"assumedOfflinePeriodSecs":300,\
"fetchJarsEagerly":true,"fetchSourcesEagerly":true,"xrayIndex":true,\
"description":"Created for ' + ISSUE_KEY + '",\
"repoLayoutRef" : "' + layout + '"}'
    logging.debug(data)
    return data

def main():
    """
    This is the main function that will create the remote repo and
    call other functions to add repos to it
    """
    logging.debug(name)
    layout = utilities.setlayout(ptype)
    logging.debug(layout)
    data = setdata(layout)
    for instance in urlinstances:
        try:
            response = requests.put(instance + '/api/repositories/' + name,
                                    auth=(user, pwd), headers=headers,
                                    data=data)
            response.raise_for_status()
        except requests.HTTPError:
            response = requests.post(instance + '/api/repositories/' + name,
                                     auth=(user, pwd), headers=headers,
                                     data=data)
        if response.ok:
            logging.info(response.text)
            setup_virtual_repo.main(user, pwd, ptype, urlinstances)
        else:
            logging.error(response.reason)
            logging.error(response.text)

    if response.status_code == 401:
        print("Please verify you are using api key and not the password")
    else:    
        print("Remote Repository Setup completed with respose code " + str(response.status_code))            
            

if __name__ == "__main__":
    main()
