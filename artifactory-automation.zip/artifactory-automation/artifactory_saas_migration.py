"""
Author: 		Peter Eames
Date: 		    Dec-2021
Decription: 	Script to Migrate from 1 artifactory instance to another
Version:		1.0.0 - Initial Script
"""

import getpass
import logging
import json
import sys
from ast import literal_eval
import requests
import setup_virtual_repo

# The different levels of logging, from highest urgency to lowest urgency, are:
# CRITICAL | ERROR | WARNING | INFO | DEBUG
logging.basicConfig(stream=sys.stderr, level=logging.INFO,
                    format='%(levelname)s - %(message)s')

user = input('Username: ')
pwd = getpass.getpass()
SOURCE_INSTANCE = 'https://us-artifactory.prudential.com/artifactory'
TARGET_INSTANCE = 'https://prudentialus.pe.jfrog.io/artifactory'
headers = {'content-type': 'application/json'}
ptlist = []


def setdata(url, repo):
    """ this function sets the data to be posyted to Artifactory """
    data = '{"url" : "' + url + '","username" : "' + user + '","password" : "' + pwd + '","enableEventReplication" : true,"enabled" : true, "cronExp" : "0 0 4 ? * *", "syncDeletes" : true, "syncProperties" :   true,"syncStatistics" : true, "repoKey" : "' + repo + '"}'
    #cont_repo = repo[:-5] + 'prod'
    #data = '{"cronExp":"0 0 4 ? * *","enableEventReplication":true,"replications":[{"url": "https://mnncpold2201.prudential.com/artifactory/' + cont_repo + '","username" : "' + user + '","password": "' + pwd + '","enableEventReplication": true,"enabled": true,"syncDeletes": true,"syncProperties": true,"syncStatistics" : true,"repoKey": "' + repo + '"},{"url": "' + url + '","socketTimeoutMillis": 150000,"username" : "' + user + '","password": "' + pwd + '","enableEventReplication": true,"enabled": true,"syncDeletes": true,"syncProperties": true,"syncStatistics" : true,"repoKey": "' + repo + '"}]}'  # pylint: disable=line-too-long  # noqa: E501
    return data


def check_offline(source_config):
    """ check if the remote repo is marked offline so it will not migrate """
    logging.debug(source_config.text)
    json_object = json.loads(source_config.text)
    logging.debug(json_object)
    logging.debug(json_object["offline"])
    return json_object["offline"]


def main():
    """ this function calls the other functions to sync data """
    psets = ''
    while psets != 'Y':
        psets = input("Has the Property Sets been setup? (Y/N) ")
    logging.info("Syncing the local repos from %s to %s", SOURCE_INSTANCE, TARGET_INSTANCE)
    sync_local_repos()
    logging.info("Syncing the remote repos from %s to %s", SOURCE_INSTANCE, TARGET_INSTANCE)
    sync_remote_repos()
    logging.info("Syncing the virtual repos from %s to %s", SOURCE_INSTANCE, TARGET_INSTANCE)
    sync_virtual_repos()
    logging.info("Syncing permisions from %s to %s", SOURCE_INSTANCE, TARGET_INSTANCE)
    sync_permissions()


def sync_remote_repos():
    """ compare the remote repos and setup anything missing """
    source_response = requests.get(SOURCE_INSTANCE + '/api/repositories?type=remote',
                                   auth=(user, pwd))
    logging.debug(source_response.text)
    target_response = requests.get(TARGET_INSTANCE + '/api/repositories?type=remote',
                                   auth=(user, pwd))
    logging.debug(target_response.text)
    for result in literal_eval(source_response.text):
        repo = result.get('key')
        source_config = requests.get(SOURCE_INSTANCE + '/api/repositories/' + repo,
                                     auth=(user, pwd))
        if check_offline(source_config):
            logging.warning('%s is offline and will not be migrated', repo)
        else:
            try:
                target_config = requests.put(TARGET_INSTANCE + '/api/repositories/' + repo,
                                             auth=(user, pwd), headers=headers,
                                             data=source_config.text)
                target_config.raise_for_status()
            except requests.HTTPError:
                target_config = requests.post(TARGET_INSTANCE + '/api/repositories/' + repo,
                                              auth=(user, pwd), headers=headers,
                                              data=source_config.text)
            if target_config.ok:
                logging.info(target_config.text)
            else:
                logging.critical(target_config.reason)
                logging.critical(target_config.text)


def sync_local_repos():
    """ compare the local repos and setup anything missing """
    source_response = requests.get(SOURCE_INSTANCE + '/api/repositories?type=local',
                                   auth=(user, pwd))
    logging.debug(source_response.text)
    target_response = requests.get(TARGET_INSTANCE + '/api/repositories?type=local',
                                   auth=(user, pwd))
    logging.debug(target_response.text)
    for result in literal_eval(source_response.text):
        repo = result.get('key')
        ptlist.append(result.get('packageType'))
        if '-local' in repo:
            source_config = requests.get(SOURCE_INSTANCE + '/api/repositories/' + repo,
                                         auth=(user, pwd))
            try:
                target_config = requests.put(TARGET_INSTANCE + '/api/repositories/' + repo,
                                             auth=(user, pwd), headers=headers,
                                             data=source_config.text)
                target_config.raise_for_status()
            except requests.HTTPError:
                target_config = requests.post(TARGET_INSTANCE + '/api/repositories/' + repo,
                                              auth=(user, pwd), headers=headers,
                                              data=source_config.text)
            data = setdata(TARGET_INSTANCE + '/' + repo, repo)
            requests.put(SOURCE_INSTANCE + '/api/replications/' + repo,
                         auth=(user, pwd), headers=headers, data=data)
            #requests.put(SOURCE_INSTANCE + '/api/replications/multiple/' + repo,
            #             auth=(user, pwd), headers=headers, data=data)
            if target_config.ok:
                logging.info(target_config.text)
            else:
                logging.critical(target_config.reason)
                logging.critical(target_config.text)


def sync_virtual_repos():
    """ compare the virtual repos and setup anything missing """
    urlinstances = [TARGET_INSTANCE]
    ptset = set(ptlist)
    for ptype in ptset:
        setup_virtual_repo.main(user, pwd, ptype, urlinstances)


def sync_permissions():
    """ compare the permissions and setup anything missing """
    target_permisisons = []
    source_response = requests.get(SOURCE_INSTANCE + '/api/security/permissions',
                                   auth=(user, pwd))
    logging.debug(source_response.text)
    target_response = requests.get(TARGET_INSTANCE + '/api/security/permissions',
                                   auth=(user, pwd))
    logging.debug(target_response.text)
    for result in literal_eval(target_response.text):
        permission = result.get('name')
        if permission not in target_permisisons:
            target_permisisons.append(permission)
    logging.debug(target_permisisons)
    for result in literal_eval(source_response.text):
        permission = result.get('name')
        if 'Remote' not in permission:
            source_config = requests.get(SOURCE_INSTANCE
                                         + '/api/security/permissions/'
                                         + permission, auth=(user, pwd))
            target_config = requests.put(TARGET_INSTANCE +
                                         '/api/security/permissions/'
                                         + permission, auth=(user, pwd),
                                         headers=headers,
                                         data=source_config.text)
            if target_config.ok:
                logging.info(target_config.text)
            else:
                logging.critical(target_config.reason)
                logging.critical(target_config.text)


def get_storage_data():
    """ tmp request for JFrog to get storage data """
    response = requests.get(SOURCE_INSTANCE + '/api/storagesummary',
                            auth=(user, pwd), headers=headers)
    with open('sourceinfo.json', 'w', encoding='utf-8') as outputfile:
        json.dump(response.text, outputfile, ensure_ascii=False, indent=4)
    response = requests.get(TARGET_INSTANCE + '/api/storagesummary',
                            auth=(user, pwd), headers=headers)
    with open('targetinfo.json', 'w', encoding='utf-8') as outputfile:
        json.dump(response.text, outputfile, ensure_ascii=False, indent=4)


def clean_test_box():
    """ delete all from the test server so the migration script can be run fresh """
    target_response = requests.get(TARGET_INSTANCE + '/api/repositories',
                                   auth=(user, pwd))
    logging.debug(target_response.text)
    for result in literal_eval(target_response.text):
        repo = result.get('key')
        print('deleting ' + TARGET_INSTANCE + '/api/repositories/' + repo)
        requests.delete(TARGET_INSTANCE + '/api/repositories/' + repo,
                        auth=(user, pwd))


if __name__ == "__main__":
    main()
    # clean_test_box()
    # get_storage_data()
