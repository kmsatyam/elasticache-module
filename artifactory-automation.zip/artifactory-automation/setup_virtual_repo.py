"""
Author: 		Peter Eames
Date: 		    May 2021
Decription: 	Setup Virtual artifactory repo
Version:		2.0.0
Notes:          Script will run over all Artifactory instances listed in the urlInstances list
                Script requires the following inputs:
                    Admin user ID
                    Admin user Password
                    Name of the repo to be setup (exclude -virtual)
Changes:        2.0.0 - Nov 21 - Peter Eames
                    Changes to meet pylint standards,
                    removed common functions to utilities
                    make script callable from local and remote setup scripts
"""

import json
import sys
from ast import literal_eval
import logging
import requests
import utilities

# The different levels of logging, from highest urgency to lowest urgency, are:
# CRITICAL | ERROR | WARNING | INFO | DEBUG
logging.basicConfig(stream=sys.stderr, level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

headers = {'content-type': 'application/json'}
javatypes = ['maven', 'gradle', 'ivy']


def setdata(name, layout, ptype):
    """ This functions sets the data to be sent through for the creation of the virtual repo """
    #data = '{"key":"' + name + '","rclass":"virtual",\
    #        "packageType":"' + ptype + '","repoLayoutRef" : "' + layout + '"}'
    data = '{"key":"' + name + '","rclass":"virtual",\
            "packageType":"' + ptype + '"}'
    logging.debug(data)
    return data


def setname(ptype):
    """ This functions sets the name of the virtual repo """
    if ptype.lower() in javatypes:
        return 'libs-release,libs-snapshot,plugins-release,plugins-snapshot'
    if ptype.lower() == 'composer':
        return 'php-virtual'
    return ptype.lower() + '-virtual'


def main(user, pwd, ptype, urlinstances):
    """
    This is the main function that will create the virtual repo and
    call other functions to add repos to it
    """
    name = setname(ptype)
    logging.debug(name)
    layout = utilities.setlayout(ptype)
    logging.debug(layout)
    name_list = name.split(",")
    for vname in name_list:
        data = setdata(vname, layout, ptype)
        for url in urlinstances:
            try:
                response = requests.put(url + '/api/repositories/' + vname,
                                        auth=(user, pwd), headers=headers,
                                        data=data)
                response.raise_for_status()
            except requests.HTTPError:
                response = requests.post(url + '/api/repositories/' + vname,
                                         auth=(user, pwd), headers=headers,
                                         data=data)
            if not response.ok:
                logging.error(response.reason)
                logging.error(response.text)
            add_repos(user, pwd, url, vname, ptype)


def add_repos(user, pwd, url, name, ptype):
    """ This functions adds the repos to the virtual repos """
    repolist = []
    create_local_list(user, pwd, url, name, repolist, ptype)
    create_remote_list(user, pwd, url, repolist, ptype)
    data = '{"repositories":' + json.dumps(repolist) + '}'
    response = requests.post(url + '/api/repositories/' + name,
                             auth=(user, pwd), headers=headers,
                             data=data)
    if response.ok:
        logging.info(response.text)
    else:
        logging.error(response.reason)
        logging.error(response.text)


def create_local_list(user, pwd, url, name, repolist, ptype):
    """
    This functions creates a list of the local repos to be
    added in the order of local then mirror
    """
    if ptype.lower() in javatypes:
        for jtype in javatypes:
            response = requests.get(url + '/api/repositories?type=local&packageType=' + jtype,
                                    auth=(user, pwd))
            logging.debug(response.text)
            for result in literal_eval(response.text):
                if name + '-local' in result.get('key') or 'ext-' + name + '-local' \
                     in result.get('key') or '-production-local' in result.get('key'):
                    repolist.append(result.get('key'))
                logging.debug(result.get('key'))
        for jtype in javatypes:
            response = requests.get(url + '/api/repositories?type=local&packageType=' + jtype,
                                    auth=(user, pwd))
            logging.debug(response.text)
            for result in literal_eval(response.text):
                if (name + '-prod' in result.get('key') or name + '-cont' in result.get('key')
                        or '-production-prod' in result.get('key') or '-production-cont'
                        in result.get('key')):
                    repolist.append(result.get('key'))
                logging.debug(result.get('key'))
    else:
        response = requests.get(url + '/api/repositories?type=local&packageType=' + ptype,
                                auth=(user, pwd))
        logging.debug(response.text)
        for result in literal_eval(response.text):
            if '-local' in result.get('key'):
                repolist.append(result.get('key'))
            logging.debug(result.get('key'))
        for result in literal_eval(response.text):
            if '-prod' in result.get('key') or '-cont' in result.get('key'):
                repolist.append(result.get('key'))
            logging.debug(result.get('key'))
    return repolist


def create_remote_list(user, pwd, url, repolist, ptype):
    """ This functions adds the remote repos to the repo list to be added to the virtual repo """
    if ptype.lower() in javatypes:
        for jtype in javatypes:
            response = requests.get(url + '/api/repositories?type=remote&packageType=' + jtype,
                                    auth=(user, pwd))
            logging.debug(response.text)
            for result in literal_eval(response.text):
                repolist.append(result.get('key'))
            logging.debug(repolist)
    else:
        response = requests.get(url + '/api/repositories?type=remote&packageType=' + ptype,
                                auth=(user, pwd))
        logging.debug(response.text)
        for result in literal_eval(response.text):
            repolist.append(result.get('key'))
        logging.debug(repolist)
    return repolist
