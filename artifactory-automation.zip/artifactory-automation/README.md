![JFrog Logo](./images/Jfrog_Logo.svg)

# JFrog Platform Automation Scripts

![License](./images/license.svg)

[Report Bug](https://servicedesk.prudential.com/servicedesk/customer/portal/7/create/) | [Request Feature](https://servicedesk.prudential.com/servicedesk/customer/portal/7/create/)

## About The Project

This project has a set of scripts call the JFrog Platform API to perform repeatable tasks to enable Self-Service for the end user.  The Jenkinsfile is used to orchestrate the API calls, however the scripts are self contained and can be run standalone.

### Built With

* [Python](https://www.python.org/)

## Getting Started

These scripts can be run both locally and from a Jenkins server.
To get a local copy up and running follow these simple example steps.

### Prerequisites

This is an example of how to list things you need to use the software and how to install them.

* Install [Python 3.x](https://www.python.org/downloads/)
  * As part of the installation ensure pip is also installed.
* Configure python to pull artifacts from Artifactory
* Install the below dependencies

  ```sh
  pip install requests
  ```

### Usage

| Script | Description |
|-------|----|
| artifactory_saas_cutover_testing | |
| artifactory_saas_migration | |
| artifactory_saas_migration_check | |
| setup_local_repo.py | |
| setup_remote_repo.py | |
| setup_virtual_repo.py | |
| utilities | |

## Contact

Automation Services | Capabilities & Tooling Team | Rogue One Pod
[Global Technology SDE Rogue One](mailto:global.technology.sde.rogue.one@prudential.com)
