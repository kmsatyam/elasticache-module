"""
Author: 		Peter Eames
Date: 		    March-2022
Decription: 	Script check setup between 2 instances
Version:		1.0.0 - Initial Script
"""

import getpass
import json
import logging
import os
import re
import sys
import time
from ast import literal_eval
import ldap
import requests

# The different levels of logging, from highest urgency to lowest urgency, are:
# CRITICAL | ERROR | WARNING | INFO | DEBUG
logging.basicConfig(stream=sys.stderr, level=logging.INFO,
                    format='%(asctime)s | %(levelname)s | %(message)s')

user = input('Username: ')
pwd = getpass.getpass()
SOURCE_INSTANCE = 'https://p2ehowld204.prudential.com/artifactory/'
#TARGET_INSTANCE = 'https://prudentialus.pe.jfrog.io/artifactory'
TARGET_INSTANCE = 'https://us-artifactory.prudential.com/artifactory'
headers = {'content-type': 'application/json'}
racfid = re.compile(r'[a-zA-Z]\d{6}[a-z]?')


def check_repos(rtype):
    source_count=0
    target_count=0
    source_response = requests.get(SOURCE_INSTANCE + '/api/repositories?type=' + rtype,
                                   auth=(user, pwd), verify=False)
    logging.debug(source_response.text)
    for result in literal_eval(source_response.text):
        repo = result.get('key')
        if  rtype == 'local':
            if '-local' in repo:
                source_count=source_count + 1
        else:
            source_count=source_count + 1
    logging.debug(source_count)
    target_response = requests.get(TARGET_INSTANCE + '/api/repositories?type=' + rtype,
                                   auth=(user, pwd), verify=False)
    logging.debug(target_response.text)
    for result in literal_eval(target_response.text):
        target_count=target_count + 1
    logging.debug(target_count)
    logging.info('%s repos check complete ' + u'\u2713', rtype.title())
    if source_count == target_count:
        logging.info('There are %d %s repos setup in the source env and %d %s repos setup in the target env',source_count, rtype,target_count,rtype)
    else:
        logging.error('There are missing %s repos.  Source = %d %s repos vs Target = %d %s repos',rtype, source_count, rtype,target_count,rtype)
        for result in literal_eval(source_response.text):
            repo = result.get('key')
            found = False
            for result in literal_eval(target_response.text):
                if repo == result.get('key'):
                    found = True
            if not found:
                logging.warning('%s not found in target',repo)
    print('')


def check_permissions():
    source_count=0
    target_count=0
    source_response = requests.get(SOURCE_INSTANCE + '/api/security/permissions',
                                   auth=(user, pwd), verify=False)
    logging.debug(source_response.text)
    for result in literal_eval(source_response.text):
        source_count=source_count + 1
    logging.debug(source_count)
    target_response = requests.get(TARGET_INSTANCE + '/api/security/permissions',
                                   auth=(user, pwd), verify=False)
    logging.debug(target_response.text)
    for result in literal_eval(target_response.text):
        target_count=target_count + 1
    logging.debug(target_count)
    logging.info('Permissions check complete ' + u'\u2713')
    if (target_count - source_count) == 6:
        logging.info('There are %d permissions in the source env and %d permissions in the target env',source_count, target_count)
    else:
        logging.error('There are missing permissions.  Source = %d permissions vs Target = %d permissions',source_count,target_count)
    for result in literal_eval(source_response.text):
        permission = result.get('name')
        found = False
        for result in literal_eval(target_response.text):
            if permission.upper() == result.get('name').upper():
                found = True
        if not found:
            logging.warning('%s permission not found in target',permission)
    print('')


def check_group():
    source_count=0
    target_count=0
    source_response = requests.get(SOURCE_INSTANCE + '/api/security/groups',
                                   auth=(user, pwd), verify=False)
    logging.debug(source_response.text)
    for result in literal_eval(source_response.text):
        source_count=source_count + 1
    logging.debug(source_count)
    target_response = requests.get(TARGET_INSTANCE + '/api/security/groups',
                                   auth=(user, pwd), verify=False)
    logging.debug(target_response.text)
    for result in literal_eval(target_response.text):
        target_count=target_count + 1
    logging.debug(target_count)
    logging.info('Groups check complete ' + u'\u2713')
    if target_count >= source_count:
        logging.info('There are %d groups in the source env and %d groups in the target env',source_count, target_count)
    else:
        logging.error('There are missing groups.  Source = %d groups vs Target = %d groups',source_count,target_count)
    for result in literal_eval(source_response.text):
        group = result.get('name').upper()
        found = False
        for result in literal_eval(target_response.text):
            if group == result.get('name').upper():
                found = True
        if not found:
            logging.warning('%s group not found in target',group)
    print('')


def check_artifacts():
    logging.info('Checking artifact replication')
    requests.post(SOURCE_INSTANCE + '/api/storageinfo/calculate',
                  auth=(user, pwd), headers=headers, verify=False)
    requests.post(TARGET_INSTANCE + '/api/storageinfo/calculate',
                  auth=(user, pwd), headers=headers, verify=False)
    time.sleep(100)
    source_response = requests.get(SOURCE_INSTANCE + '/api/storageinfo',
                                   auth=(user, pwd), headers=headers, verify=False)
    target_response = requests.get(TARGET_INSTANCE + '/api/storageinfo',
                                   auth=(user, pwd), headers=headers, verify=False)
    for sresult in eval(source_response.text)["repositoriesSummaryList"]:
        repo = sresult.get('repoKey')
        rtype = sresult.get('repoType')
        source_count = sresult.get('filesCount')
        manual = False
        if rtype == 'LOCAL' and repo != 'artifactory-build-info':
            for tresult in eval(target_response.text)["repositoriesSummaryList"]:
                if tresult.get('repoKey') == repo:
                    target_count = tresult.get('filesCount')
                    if source_count != target_count:
                        if source_count > target_count:
                            diff = source_count - target_count
                            if diff >= 1000:
                                logging.critical('There are differences in artifact counts in ' + repo + '.  Source = %d items vs Target = %d items (%d items)', source_count, target_count, diff)
                            elif diff >= 100:
                                logging.error('There are differences in artifact counts in ' + repo + '.  Source = %d items vs Target = %d items (%d items)', source_count, target_count, diff)
                            else:
                                logging.warning('There are differences in artifact counts in ' + repo + '.  Source = %d items vs Target = %d items (%d items)', source_count, target_count, diff)
                            try:
                                os.mkdir('repo-details')
                            except OSError:
                                pass
                            if diff <= 300 and diff > 0:
                                logging.info('Attempting manual update')
                                manual = True
                                # with open('repo-details/' + repo + '.txt', 'w') as f:
                                #     f.write(' '.join(detailed_artifact_check(repo, manual)))
                        else:
                            logging.info('There are differences in artifact counts in ' + repo + '.  Source = %d items vs Target = %d items', source_count, target_count)
    stotalartifacts = source_response.json()
    stotalartifacts = stotalartifacts['binariesSummary']['artifactsCount']
    ttotalartifacts = target_response.json()
    ttotalartifacts = ttotalartifacts['binariesSummary']['artifactsCount']
    logging.info('There are %s artifacts on-prem and %s artifacts in SAAS', stotalartifacts, ttotalartifacts)
    print('')


def detailed_artifact_check(repo, manual):
# /api/storage/libs-release-local/org/acme?list&deep=1&listFolders=1&mdTimestamps=1
    missinglist=[]
    source_response = requests.get(SOURCE_INSTANCE + '/api/storage/'+ repo +
                                   '?list&deep=1', auth=(user, pwd),
                                   headers=headers, verify=False)
    target_response = requests.get(TARGET_INSTANCE + '/api/storage/'+ repo +
                                   '?list&deep=1', auth=(user, pwd),
                                   headers=headers, verify=False)
    json_object = json.loads(source_response.text)
    sfiles = json_object["files"]
    json_object = json.loads(target_response.text)
    tfiles = json_object["files"]
    for s in sfiles:
        uri = s.get('uri')
        found = False
        for t in tfiles:
            if t.get('uri') == uri:
                found = True
        if not found:
            if manual:
                local_filename = uri.split('/')[-1]
                try:
                    with requests.get(SOURCE_INSTANCE + '/' + repo + uri + '?skipUpdateStats=true', auth=(user, pwd), headers=headers, stream=True) as r:
                        r.raise_for_status()
                        with open(local_filename, 'wb') as f:
                            for chunk in r.iter_content(chunk_size=8192):
                                f.write(chunk)
                    with open(local_filename, 'rb') as myfile:
                        upload = requests.put(TARGET_INSTANCE + '/' + repo + uri, data=myfile, auth=(user, pwd))
                    if upload.ok:
                        logging.info('%s uploaded successfully', local_filename)
                    else:
                        missinglist.append(uri)
                except IOError as e:
                    logging.error('%s', e)
                    missinglist.append(uri)
                finally:
                    if os.path.exists(local_filename):
                        try:
                            os.remove(local_filename)
                        except OSError as e:
                            logging.error('%s', e)
                # Trigger replication
            else:
                missinglist.append(uri)
    return missinglist


def check_users():
    logging.info('Checking users can edit profile')
    response = requests.get(SOURCE_INSTANCE + '/api/security/users', auth=(user, pwd), verify=False)
    data = '{"profileUpdatable": true}'
    for result in literal_eval(response.text):
        auser = result.get('name')
        URI = result.get('uri')
        if racfid.search(auser):
            response = requests.post(URI, headers=headers, auth=(user, pwd), data=data)


def update_japan_users():
    logging.info('Enabling internal password for Japan Users')
    ad_usr = input('Enter a Username that has AD access: ')
    ad_pwd = getpass.getpass()
    connect = ldap.initialize('ldap://adssl.prudential.com')
    connect.simple_bind_s('CN=' + ad_usr + ',OU=CTS,OU=People,DC=prudential,DC=com', ad_pwd)
    dictionary = {}

    user_list=['admin', 'X206548','X255576','X175731A','X176518A','X230394','pim-p_ppc_art_deploy']
    acc_groups = 'GT-ACC_ARTIFACTORY_PGF_READERS,GT-ACC_ARTIFACTORY_PGF_PUBLISH,GT-ACC_ARTIFACTORY_PGF_OWNERS,gt-acc_artifactory_gib_owners,gt-acc_artifactory_gib_publish,gt-acc_artifactory_gib_readers,gt-acc_artifactory_poj_owners,gt-acc_artifactory_poj_publish,gt-acc_artifactory_poj_readers'
    group_list = acc_groups.split (",")
    for group in group_list:
        result = connect.search_s('OU=People,DC=prudential,DC=com',
                                  ldap.SCOPE_SUBTREE,'CN=' + group,['*'])
        logging.debug(result)
        for entry in result:
            dictionary = entry[1]
            m = dictionary.get('member')
            for usr in m:
                id = usr.decode("utf-8").split(",",1)
                id = id[0][3:]
                #print(id)
                if racfid.search(id):
                    if id not in user_list:
                        user_list.append(id)
    print(user_list)
    response = requests.get(TARGET_INSTANCE + '/api/security/users', auth=(user, pwd), verify=False)
    for result in literal_eval(response.text):
        auser = result.get('name')
        URI = result.get('uri')
        uresponse = requests.get(URI, headers=headers, auth=(user, pwd), verify=False)
        userdetails = uresponse.json()
        intpwd = userdetails['internalPasswordDisabled']
        if auser.upper() in user_list or auser.lower() in user_list:
            data = '{"internalPasswordDisabled": false, "password": "Pa$$word1"}'
            if intpwd:
                print(requests.get(URI, headers=headers, auth=(user, pwd)).text)
                uresponse = requests.post(URI, headers=headers, auth=(user, pwd), data=data, verify=False)
                print(requests.get(URI, headers=headers, auth=(user, pwd)).text)
        # else:
        #     data = '{"internalPasswordDisabled": true}'
        #     if not intpwd:
        #         print(requests.get(URI, headers=headers, auth=(user, pwd)).text)
        #         uresponse = requests.post(URI, headers=headers, auth=(user, pwd), data=data)
        #         print(requests.get(URI, headers=headers, auth=(user, pwd)).text)
        if not uresponse.ok:
            logging.critical(uresponse.reason)
            logging.critical(uresponse.text)


def main():
    """ this function calls the other functions to sync data """
    check_repos('local')
    check_repos('remote')
    check_repos('virtual')
    check_group()
    check_permissions()
    check_artifacts()
    #check_users()
    update_japan_users()


if __name__ == "__main__":
    main()
