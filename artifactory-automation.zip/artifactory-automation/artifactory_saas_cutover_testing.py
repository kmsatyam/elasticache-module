#!/bin/python
import sys, getpass, requests
#
try:
    user = sys.argv[1]
except IndexError:
    user = input('Username: ')
try:
    pwd = sys.argv[2]
except IndexError:
    pwd = getpass.getpass('Provide API Key: ')
try:
    url = sys.argv[3]
except IndexError:
    url = input('Provide Artifactory URL: ')
#
#url = "https://us-artifactory-test.prudential.com/artifactory"
repo = "/pru-enterprise-approved-opensource-local/"
auth=(user,pwd)
#
with open('migration.testfile', 'w') as file:
    file.write('THIS IS A TEST FILE FOR JFROG SAAS MIGRATION TEST')
    file.write('\n')
file = "migration.testfile"
data = open(file)
#
resp1 = requests.get(url)
resp2 = requests.get(url + repo, auth=auth)
resp3 = requests.put(url + repo + file, auth=auth, data=data)
resp4 = requests.get(url + repo + file, auth=auth)
resp5 = requests.delete (url + repo + file, auth=auth)
resp6 = requests.get(url + repo + file, auth=auth)
#
if resp1.status_code == 200:
    print('Reponse: ' + str(resp1.status_code) + '\tSUCESS: Connected to ' + url)
else:
    print('Reponse: ' + str(resp1.status_code) + '\tFAILED: Error Connecting to ' + url)
#
if resp2.status_code == 200:
    print('Reponse: ' + str(resp2.status_code) + '\tSUCESS: Connected to ' + url + repo)
else:
    print('Reponse: ' + str(resp2.status_code) + '\tFAILED: Error Connecting to ' + url + repo)
#
if resp3.status_code == 201:
    print('Reponse: ' + str(resp3.status_code) + '\tSUCESS: Deployed Artifact ' + file + ' to repo ' + repo)
else:
    print('Reponse: ' + str(resp3.status_code) + '\tFAILED: Error Deploying Artifact ' + file + ' to repo ' + repo)
#
if resp4.status_code == 200:
    print('Reponse: ' + str(resp4.status_code) + '\tSUCESS: Retrived Deployed Artifact ' + file + ' from repo ' + repo)
    print('\t\t\tFile Contents: ' + str(resp4.content))
else:
    print('Reponse: ' + str(resp4.status_code) + '\tFAILED: Error Retriving Deployed Artifact ' + file + ' from repo ' + repo)
#
if resp5.status_code == 204:
    print('Reponse: ' + str(resp5.status_code) + '\tSUCESS: Deleted Deployed Artifact ' + file + ' from repo ' + repo)
else:
    print('Reponse: ' + str(resp5.status_code) + '\tFAILED: Error Deleting Deployed Artifact ' + file + ' from repo ' + repo)
#
if resp6.status_code == 404:
    print('Reponse: ' + str(resp6.status_code) + '\tSUCESS: Deleted Artifact ' + file + ' not found in repo ' + repo)
else:
    print('Reponse: ' + str(resp6.status_code) + '\tFAILED: Deleted Artifact ' + file + ' still exists in repo ' + repo)
