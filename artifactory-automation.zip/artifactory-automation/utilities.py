'''
Author: 		Peter Eames
Date: 		    Nov 2021
Decription: 	Small functions that are repeatable across the
                artifactory onboarding scripts
Version:		2.0.0
Changes:        Added functions to setup/update permissions as
                this will be called from setting up of local repos
'''

import json
import logging
from ast import literal_eval
import requests
from security import active_directory, sailpoint
from SNowReqUpdate import reqUpdate

HEADERS = {'content-type': 'application/json'}
JUSTIFICATION = 'New Artifactory group as part of Self-Service setup'
READ_SA = 'gt-p-sde-artif-read'
DEPLOY_SA = 'gt-p-sde-artif-dploy'
SD_URL = 'https://servicedesk.prudential.com/'


def setlayout(ptype):
    ''' Choose the correct default layout based on the repository type '''
    specialtypes = ['bower', 'composer', 'conan', 'go', 'ivy',
                    'npm', 'nuget', 'puppet', 'sbt', 'vcs']
    if ptype.lower() in ['maven', 'gradle']:
        return 'maven-2-default'
    if ptype.lower() in specialtypes:
        return ptype.lower() + '-default'
    return 'simple-default'


def setknownexcluded(bu_name):
    ''' set any known exclusions for permissions '''
    if bu_name.lower() == "ili":
        return ["com/prudential/lifepro/**", "com/prudential/wfi/**"]
    return []

def overide_bu_name(bu_name):
    # Legacy BU Name - Exceptions
    if bu_name.lower() == 'gt-apim': bu_name = 'apim'
    if bu_name.lower() == 'gt-edm' : bu_name = 'edm'
    if bu_name.lower() == 'corp'   : bu_name = 'hr'
    return(bu_name)

def extract_bu_name(reponame):
    bu_prefix = reponame.split(sep='-')
    logging.debug('%s', bu_prefix[0])
    pkg_2part = ['libs-release', 'libs-snapshot', 'plugins-release', 'plugins-snapshot', 'gradle-release', 'gradle-snapshot', 'libs-production']
    pkg_3part = ['libs-pre-production']
    if any(item.lower() in reponame.lower() for item in pkg_3part):
       bu_name = ('-'.join(bu_prefix[:-4]))
    elif any(item.lower() in reponame.lower() for item in pkg_2part):
       bu_name = ('-'.join(bu_prefix[:-3]))
    else:
       bu_name = ('-'.join(bu_prefix[:-2]))
    # Legacy BU Name - Exceptions
    overide_bu_name(bu_name)
    return(bu_name)

def consold_bu_list(bu_name):
    bu_list = []
    # Legacy BU Name - Exceptions
    bu_name = overide_bu_name(bu_name)
    bu_prefix = bu_name.split(sep='-')
    logging.debug('%s', bu_prefix[0])
    # Legacy BU Name - Exceptions
    if   bu_prefix[0].lower() in ('apim')         : bu_list = ['apim', 'gt-apim'] ; perm_name = bu_name
    elif bu_prefix[0].lower() in ('edm')          : bu_list = ['edm', 'gt-edm']   ; perm_name = bu_name
    elif bu_prefix[0].lower() in ('hr')           : bu_list = ['corp', 'hr']      ; perm_name = bu_name
    elif bu_prefix[0].lower() in ('ess', 'amfm')  : bu_list = ['ess', 'amfm']     ; perm_name = 'amfm'
    elif bu_prefix[0].lower() in ('gi', 'wsg')    : bu_list = ['gi', 'wsg']       ; perm_name = 'wsg'
    elif bu_prefix[0].lower() in ('pfi')          : bu_list = ['pfi']             ; perm_name = 'pfi'
    elif bu_prefix[0].lower() == ('pru')          : bu_list = ['pru']             ; perm_name = 'pru'
    # Standard BU Names
    else                                          : bu_list.append(bu_name)       ; perm_name = bu_name
    return bu_list, perm_name

def setpermissions(user, pwd, bu_name, url, sd_user, sd_pwd, key=None):
    ''' create or update permissions on repos '''
    repo_list = []
    response = requests.get(url + '/api/repositories?type=local',
                            auth=(user, pwd))
    logging.debug(response.text)
    for result in literal_eval(response.text):
        repo = result.get('key')
        get_repo_bu = extract_bu_name(repo)
        lst_repo_bu,  tgt_perm_bu = consold_bu_list(get_repo_bu)
        for vald_bu in lst_repo_bu:
              if bu_name.lower() == vald_bu and repo.endswith('-local'):
                repo_list.append(repo)
                perm_tget = tgt_perm_bu
    logging.debug(repo_list)
    logging.debug(perm_tget)
    print(repo_list)
    name = perm_tget.upper()
    logging.debug(name)
    exclude_pattern = setknownexcluded(bu_name)
    logging.debug(exclude_pattern)
    group_list = getgroups(user, pwd, bu_name, url)
    ''' BugFix for SetPermission failure due to groupname case sensitivity in data payload '''
    for i in range(len(group_list)):
        response = requests.get(url + '/api/security/groups/' + group_list[i], auth=(user, pwd))
        if response.status_code == 404:
            a = group_list[i]
            group_list[i] = a.lower()
    ''' BugFix Ends '''
    data = '{"name": "' + name + '", "repo": {"include-patterns": ["**"],\
            "exclude-patterns":' + json.dumps(exclude_pattern) + ',\
            "repositories":' + json.dumps(repo_list) + ', "actions": \
            {"groups" : {"' + group_list[0] + '" : \
            ["read", "annotate", "write", "delete", "managedXrayMeta"],\
            "' + group_list[1] + '" : ["read", "annotate", "write"],\
            "' + group_list[2] + '" : ["read", "annotate"]}}},\
            "build": {"repositories": ["artifactory-build-info"], \
            "actions": {"groups" : {"' + group_list[0] + '" : \
            ["read", "annotate", "write"],"' + group_list[1] + '" : \
            ["read", "annotate", "write"],"' + group_list[2] + '" : \
            ["read", "annotate"]}}}}'
    logging.debug(data)
    response = requests.put(url + '/api/v2/security/permissions/' + name,
                            auth=(user, pwd), headers=HEADERS, data=data)
    if "PASSD-" in key:
        add_sd_comment(sd_user, sd_pwd, key, 'Updated permission ' + name)
    if not response.ok:
        logging.error(response.reason)
        logging.error(response.text)


def getgroups(user, pwd, bu_name, url):
    # Legacy BU Name - Exceptions
    bu_name = overide_bu_name(bu_name)
    """ get the groups that relate to the BU """
    response = requests.get(url + '/api/security/groups', auth=(user, pwd))
    logging.debug(response.text)
    group_list = ['', '', '']
    for result in literal_eval(response.text):
        if (bu_name + '-' in result.get('name')
                and '_admin' in result.get('name')
                and bu_name.upper() != 'GT'):
            group_list[0] = result.get('name')
        elif ('_' + bu_name + '_' in result.get('name')
              and '_admin' in result.get('name')):
            group_list[0] = result.get('name')
        elif ('_' + bu_name + '_' in result.get('name')
              and '_owners' in result.get('name')):
            group_list[0] = result.get('name')
        else:
            groupname = 'GT-ACC_ARTIFACTORY_' + bu_name.upper() + '_OWNERS'
    if group_list[0] == '':
        group_list[0] = groupname.upper()
    for result in literal_eval(response.text):
        if (bu_name + '-' in result.get('name')
                and '_publish' in result.get('name')):
            group_list[1] = result.get('name')
        elif (bu_name + '-' in result.get('name')
              and '_deploy' in result.get('name')):
            group_list[1] = result.get('name')
        elif ('_' + bu_name + '_' in result.get('name')
              and '_publish' in result.get('name')):
            group_list[1] = result.get('name')
        elif ('_' + bu_name + '_' in result.get('name')
              and '_deploy' in result.get('name')):
            group_list[1] = result.get('name')
        else:
            groupname = 'GT-ACC_ARTIFACTORY_' + bu_name.upper() + '_PUBLISH'
    if group_list[1] == '':
        group_list[1] = groupname.upper()
    for result in literal_eval(response.text):
        if (bu_name + '-' in result.get('name')
                and '_readers' in result.get('name')):
            group_list[2] = result.get('name')
        elif ('_' + bu_name + '_' in result.get('name')
              and '_readers' in result.get('name')):
            group_list[2] = result.get('name')
        else:
            groupname = 'GT-ACC_ARTIFACTORY_' + bu_name.upper() + '_READERS'
    if group_list[2] == '' and bu_name.lower() != 'pru':
        group_list[2] = groupname.upper()
    logging.debug(len(group_list))
    logging.debug(group_list)
    for group in group_list:
        checkgroups(user, pwd, group, url)
    return group_list


def checkgroups(user, pwd, group, url):
    """ create a local group if the LDAP group has not been imported yet """
    response = requests.get(url + '/api/security/groups', auth=(user, pwd))
    creategroup = True
    for result in literal_eval(response.text):
        if group.lower() == result.get('name').lower():
            creategroup = False
            break
    if creategroup:
        data = '{"name" : "' + group.upper() + '"}'
        response = requests.put(url + '/api/security/groups/' + group.upper(),
                                auth=(user, pwd), headers=HEADERS, data=data)
        if not response.ok:
            logging.error(response.reason)
            logging.error(response.text)


def setup_group_ad(bu_id, sd_usr, sd_pwd, requestor, powner, sowner, owners_mbr,
                   publish_mbr, readers_mbr, issue_key=None,
                   sailpointid=None, sailpointpwd=None):
    # Legacy BU Name - Exceptions
    bu_id = overide_bu_name(bu_id)
    """ setup the new group in Active Directory """
    state = 'success'
    valid = []
    group_details = []
    group_list = []
    group_types = ['owners', 'publish', 'readers']
    for gtype in group_types:
        group = 'GT-ACC_ARTIFACTORY_' + bu_id.upper() + '_' + gtype.upper()
        if not active_directory.validate(sd_usr, sd_pwd, 'group', group):
            group_list.append(group)
    logging.debug(group_list)
    if len(group_list) > 0:
        logging.info('Validating Requestor ID:')
        valid.append(active_directory.validate(sd_usr, sd_pwd, 'user',
                     requestor))
        logging.info('Validating Primary Owner ID:')
        valid.append(active_directory.validate(sd_usr, sd_pwd, 'user',
                     powner))
        logging.info('Validating Secondary Owner ID:')
        valid.append(active_directory.validate(sd_usr, sd_pwd, 'user',
                     sowner))
        logging.debug(valid)
        if False not in valid:
            if 'GT-ACC_ARTIFACTORY_' + bu_id.upper() + '_OWNERS':
                owners_mbr = member_list(sd_usr, sd_pwd, requestor, owners_mbr)
                owner_group = {'pownerid': powner, 'sownerid': sowner,
                            'grpname': 'GT-ACC_ARTIFACTORY_' + bu_id.upper() + '_OWNERS',
                            'description': 'Full Read, Write, Delete access to ' + bu_id.upper() + ' Artifactory Repos',
                            'ranking': '1', 'developerid': requestor,
                            'members': owners_mbr,
                            'justification': JUSTIFICATION}
                group_details.append(owner_group)
                if "PASSD-" in issue_key:
                    add_sd_comment(sd_usr, sd_pwd, issue_key,
                                   'Creating GT-ACC_ARTIFACTORY_' + bu_id.upper() + '_OWNERS')
                logging.info('Owners Members list: %s', owners_mbr)
            if 'GT-ACC_ARTIFACTORY_' + bu_id.upper() + '_PUBLISH':
                publish_mbr = member_list(sd_usr, sd_pwd, requestor, publish_mbr) + ',' + DEPLOY_SA
                publisher_group = {'pownerid': powner, 'sownerid': sowner,
                                'grpname': 'GT-ACC_ARTIFACTORY_' + bu_id.upper() + '_PUBLISH',
                                'description': 'Read, Write access to ' + bu_id.upper() + ' Artifactory Repos',
                                'ranking': '1', 'developerid': requestor,
                                'members': publish_mbr,
                                'justification': JUSTIFICATION}
                group_details.append(publisher_group)
                if "PASSD-" in issue_key:
                    add_sd_comment(sd_usr, sd_pwd, issue_key,
                                   'Creating GT-ACC_ARTIFACTORY_' + bu_id.upper() + '_PUBLISH')
                logging.info('Publish Members list: %s', publish_mbr)
            if 'GT-ACC_ARTIFACTORY_' + bu_id.upper() + '_READERS':
                readers_mbr = member_list(sd_usr, sd_pwd, requestor, readers_mbr) + ',' + READ_SA
                readers_group = {'pownerid': powner, 'sownerid': sowner,
                                'grpname': 'GT-ACC_ARTIFACTORY_' + bu_id.upper() + '_READERS',
                                'description': 'Read access to ' + bu_id.upper() + ' Artifactory Repos',
                                'ranking': '1', 'developerid': requestor,
                                'members': readers_mbr,
                                'justification': JUSTIFICATION}
                group_details.append(readers_group)
                if "PASSD-" in issue_key:
                    add_sd_comment(sd_usr, sd_pwd, issue_key,
                                   'Creating GT-ACC_ARTIFACTORY_' + bu_id.upper() + '_READERS')
                logging.info('Readers Members list: %s', readers_mbr)
            logging.debug(group_details)
            if sailpointid is not None:
                sailpoint.create_group(sailpointid, sailpointpwd, 'prod',
                                        group_details, issue_key)
            else:
                state = 'failure'
        else:
            state = 'failure'
            logging.error('Check Primary Owner and Secondary Owner IDs')
    return state


def member_list(sd_usr, sd_pwd, requestor, members):
    ''' Split out the members list and validate them against AD '''
    users = members.split(',')
    members = []
    invalid = []
    logging.info('Validating Group Members:')
    for user in users:
        if active_directory.validate(sd_usr, sd_pwd, 'user', user):
            members.append(user.strip())
        else:
            invalid.append(user.strip())
    if len(members) == 0:
        members.append(requestor)
    if len(invalid) > 0:
        invalid = ','.join(invalid)
        logging.warning('ID(s) will not be added to the group: %s',
                        invalid)
    members = ','.join(members)
    return members


def watch(url, user, pwd, bu_name, sd_usr, sd_pwd, issue_key):
    XR_URL=url.replace("/artifactory", "/xray")
    """ create a BU Watch """
    repolist=[]
    response = requests.get(url + '/api/repositories?type=local', auth=(user, pwd))
    logging.debug(response.text)
    for result in literal_eval(response.text):
        repo = result.get('key')
        get_repo_bu = extract_bu_name(repo)
        lst_repo_bu,  tgt_perm_bu = consold_bu_list(get_repo_bu)
        for vald_bu in lst_repo_bu:
            if bu_name.lower() == vald_bu  and repo.endswith('-local'):
                repolist.append(repo)
                watchname = tgt_perm_bu
    logging.debug(repolist)
    logging.debug(watchname)
    resources=[]
    repos={"type":"repository","name":"","bin_mgr_id":"default"}
    """ Remove unsupported package types from repolist, BEGIN """
    unsupported_plist=[ "chef", "cocoapods", "cran", "gitlfs", "helm", "opkg", "p2", "pub", "puppet", "swift", "terraform", "vagrant", "vcs" ]
    for p in unsupported_plist:
        for i in repolist:
            if p in i:
                repolist.remove(i)
    """ Remove unsupported package types from repolist, END """
    for i in repolist:
        tmprepos={}
        repos.update({'name':i})
        tmprepos=dict(repos)
        resources.append(tmprepos)
    logging.debug(json.dumps(resources))
    data='{"general_data":{"name":"'+watchname.upper()+'","description":"This is a watch for all '+watchname.upper()+' repositories","active":true},"project_resources":{"resources":'+json.dumps(resources)+'},"assigned_policies":[{"name":"Critical","type":"security"}]}'
    logging.debug(data)
    try:
        response = requests.post(XR_URL + '/api/v2/watches', auth=(user, pwd), headers=HEADERS, data=data)
        response.raise_for_status()
    except requests.HTTPError:
        response = requests.put(XR_URL + '/api/v2/watches/' + watchname.upper(), auth=(user, pwd), headers=HEADERS, data=data)
    if response.ok:
        logging.info(response.text)
        if "PASSD-" in issue_key:
            add_sd_comment(sd_usr, sd_pwd, issue_key,
                           'Setup watch: ' + watchname.upper())
    else:
        logging.error(response.reason)
        logging.error(response.text)

def add_sd_comment(username, password, key, msg):
    """ add a comment to service desk """
    urltopost = SD_URL + 'rest/api/2/issue/' + key + '/comment'
    requests.post(urltopost, auth=(username, password),
                  headers=HEADERS, json=({"body": msg}))


def sd_transition(username, password, key, transid):
    """ transition service desk tickets """
    urltopost = SD_URL + 'rest/api/2/issue/' + key + '/transitions'
    requests.post(urltopost, auth=(username, password), headers=HEADERS,
                  json=({"transition": {"id": transid}}))


def send_snow_failure_update(env, ticketid, snowuser, snowpwd):
    """ transition snow tickets to WIP for failures """
    msg="Failed to complete Artifactory request automatically. This is being checked and the ticket will be updated shortly"
    res = reqUpdate.sendSnowSuccessUpdate(env.upper(), msg, ticketid, "work in progress", snowuser, snowpwd)
    logging.info('%s', res)


def send_snow_successs_update(env,ticketid, snowuser, snowpwd):
    """ transition snow tickets to complete for successes """
    msg="Artifactory request has been completed automatically."
    res = reqUpdate.sendSnowSuccessUpdate(env.upper(), msg, ticketid, "closed complete", snowuser, snowpwd)
    logging.info('%s', res)
